# Fullstack Coding Challenge Solutions

This repository contains solutions for three technical tasks:

1. [DSA: Two Sum](./dsa-two-sum)
2. [MongoDB: Aggregation Pipeline](./mongodb-aggregation)
3. [React: Dynamic To-Do List App](./react-todo-app)
